package electricity.billing.system;

import javax.swing.*;

public class Main extends JFrame implements Runnable {
    Thread t;

    public void showFrame(){
        setTitle("Electricity billing System");
        setBounds(400, 200, 730, 550);
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/Welcome.jpg"));
        JLabel image = new JLabel(i1);
        add(image);

        setVisible(true);

        t = new Thread(this);
        t.start();
    }

    @Override
    public void run() {
        try {
            Thread.sleep(2000); 
            setVisible(false);

            new Login();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        Main m = new Main();
        m.showFrame();
    }
}
