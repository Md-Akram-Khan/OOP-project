package electricity.billing.system;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Login extends JFrame implements ActionListener {

    JButton login, cancel, signup;
    JTextField username, password;
    Choice logginin;

    Login() {
        super("Electricity Billing System");
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);

        // Main panel with border
        JPanel panel = new JPanel();
        panel.setBounds(20, 20, 680, 470);
        panel.setBorder(new TitledBorder(
                new LineBorder(new Color(173, 216, 230), 2),
                "Login",
                TitledBorder.LEADING,
                TitledBorder.TOP,
                null,
                new Color(72, 139, 190)
        ));
        panel.setBackground(Color.WHITE);
        panel.setLayout(null); // Set layout for custom positioning
        add(panel); // Add the panel to the frame

        // Username Label and Field
        JLabel lblusername = new JLabel("Username:");
        lblusername.setBounds(340, 80, 100, 30);
        lblusername.setFont(new Font("SansSerif", Font.BOLD, 14));
        panel.add(lblusername);

        username = new JTextField();
        username.setBounds(440, 80, 200, 30);
        panel.add(username);

        // Password Label and Field
        JLabel lblpassword = new JLabel("Password:");
        lblpassword.setBounds(340, 130, 100, 30);
        lblpassword.setFont(new Font("SansSerif", Font.BOLD, 14));
        panel.add(lblpassword);

        password = new JTextField();
        password.setBounds(440, 130, 200, 30);
        panel.add(password);

        // Login As Label and Choice
        JLabel loggininas = new JLabel("Login as:");
        loggininas.setBounds(340, 180, 100, 30);
        loggininas.setFont(new Font("SansSerif", Font.BOLD, 14));
        panel.add(loggininas);

        logginin = new Choice();
        logginin.add("Admin");
        logginin.add("Customer");
        logginin.setBounds(440, 180, 200, 30);
        panel.add(logginin);

        // Login Button
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/login.png"));
        Image i2 = i1.getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT);
        login = new JButton("Login", new ImageIcon(i2));
        login.setBounds(320, 250, 100, 30);
        login.addActionListener(this);
        panel.add(login);

        // Cancel Button
        ImageIcon i3 = new ImageIcon(ClassLoader.getSystemResource("icon/cancel.png"));
        //Image i4 = i3.getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT);
        cancel = new JButton("Cancel", i3);
        cancel.setBounds(440, 250, 100, 30);
        cancel.addActionListener(this);
        panel.add(cancel);

        // Signup Button
        ImageIcon i5 = new ImageIcon(ClassLoader.getSystemResource("icon/signup.png"));
        Image i6 = i5.getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT);
        signup = new JButton("Signup", new ImageIcon(i6));
        signup.setBounds(560, 250, 100, 30);
        signup.addActionListener(this);
        panel.add(signup);

        // Decorative Image
        ImageIcon i7 = new ImageIcon(ClassLoader.getSystemResource("icon/Login.jpg"));
        JLabel image = new JLabel(i7);
        image.setBounds(20, 80, 300, 300); // Positioned on the left side within the panel
        panel.add(image);

        // Frame properties
        setBounds(400,200,730,550);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == login) {
            String susername = username.getText();
            String spassword = password.getText();
            String user = logginin.getSelectedItem();

            try {
                Conn c = new Conn();
                String query = "select * from login where username = '" + susername + "' and password = '" + spassword + "' and user = '" + user + "'";

                ResultSet rs = c.s.executeQuery(query);

                if (rs.next()) {
                    String meter = rs.getString("meter_no");
                    setVisible(false);
                    new Project(user, meter);
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid Login");
                    username.setText("");
                    password.setText("");
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (ae.getSource() == cancel) {
            setVisible(false);
        } else if (ae.getSource() == signup) {
            setVisible(false);
            new Signup();
        }
    }

    public static void main(String[] args) {
        new Login();
    }
}
