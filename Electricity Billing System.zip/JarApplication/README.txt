### Running the JAR File for Electricity Billing System  

To successfully run the project, follow these steps:  

1. Install MySQL
   - Ensure that MySQL is installed on your machine.  

2. Set Up the Database 
   - Copy the "ebs" database to the following location:  

     C:\ProgramData\MySQL\MySQL Server 8.0\Data
  

3. Create a MySQL Connection
   - Configure a new MySQL connection with the following credentials:  
     - Username:root 
     - Port:3306 
     - Password:12345@akram

4. Run the JAR File
   - Open the command line and navigate to the **JarApplication** folder.  
   - Execute the following command:  
  
     java -jar "Electricity_Billing_System.jar" 
      

5. Troubleshooting
   - If you encounter any issues during **sign-up** or **login**, it is recommended to run the main project in **NetBeans IDE**.  
   - An another **README** file is included in the **FullProject** folder, providing additional instructions for proper setup and execution.

