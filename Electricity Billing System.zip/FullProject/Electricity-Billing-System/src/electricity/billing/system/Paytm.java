package electricity.billing.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.net.URI;

public class Paytm extends JFrame implements ActionListener {

    String meter;
    JButton back, payNow;

    Paytm(String meter) {
        this.meter = meter;
        setLayout(null);

        JLabel heading = new JLabel("Online Bill Payment");
        heading.setFont(new Font("Tahoma", Font.BOLD, 20));
        heading.setBounds(250, 20, 300, 30);
        add(heading);

        JLabel instructions = new JLabel("<html>Click the 'Pay Now' button to proceed with online payment.</html>");
        instructions.setBounds(50, 80, 600, 30);
        instructions.setFont(new Font("Tahoma", Font.PLAIN, 16));
        add(instructions);

        payNow = new JButton("Pay Now");
        payNow.setBackground(Color.BLUE);
        payNow.setForeground(Color.WHITE);
        payNow.setFont(new Font("Tahoma", Font.BOLD, 16));
        payNow.setBounds(270, 150, 150, 40);
        payNow.addActionListener(this);
        add(payNow);

        back = new JButton("Back");
        back.setBackground(Color.BLACK);
        back.setForeground(Color.WHITE);
        back.setFont(new Font("Tahoma", Font.BOLD, 14));
        back.setBounds(300, 250, 100, 30);
        back.addActionListener(this);
        add(back);

        getContentPane().setBackground(Color.WHITE);
        setBounds(400, 200, 730, 400);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == payNow) {
            try {
                Desktop.getDesktop().browse(new URI("https://paytm.com/online-payments"));
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Unable to open payment page.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else if (ae.getSource() == back) {
            setVisible(false);
            new PayBill(meter);
        }
    }

    public static void main(String[] args) {
        new Paytm("");
    }
}
