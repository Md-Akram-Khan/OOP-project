package electricity.billing.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Project extends JFrame implements ActionListener {

    String atype, meter;

    Project(String atype, String meter) {
        this.atype = atype;
        this.meter = meter;
        setTitle(atype.equals("Admin") ? "Admin Profile" : "Customer Profile");
        setBounds(400, 200, 730, 550);
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);

        if (atype.equals("Admin")) {
            JLabel masterLabel = new JLabel("Master");
            masterLabel.setBounds(200, 70, 100, 20);
            masterLabel.setFont(new Font("SansSerif", Font.BOLD, 16));
            add(masterLabel);

            JButton newCustomer = new JButton("Add New Customer");
            newCustomer.setBounds(90, 100, 270, 30);
            newCustomer.addActionListener(this);
            add(newCustomer);

            JButton customerDetails = new JButton("Customer Details");
            customerDetails.setBounds(90, 140, 270, 30);
            customerDetails.addActionListener(this);
            add(customerDetails);

            JButton depositDetails = new JButton("Deposit Details");
            depositDetails.setBounds(90, 180, 270, 30);
            depositDetails.addActionListener(this);
            add(depositDetails);

            JButton calculateBill = new JButton("Calculate Bill");
            calculateBill.setBounds(90, 220, 270, 30);
            calculateBill.addActionListener(this);
            add(calculateBill);

            JLabel utilityLabel = new JLabel("Utility");
            utilityLabel.setBounds(205, 260, 100, 20);
            utilityLabel.setFont(new Font("SansSerif", Font.BOLD, 16));
            add(utilityLabel);

            JButton notepad = new JButton("Notepad");
            notepad.setBounds(90, 290, 270, 30);
            notepad.addActionListener(this);
            add(notepad);

            JButton calculator = new JButton("Calculator");
            calculator.setBounds(90, 330, 270, 30);
            calculator.addActionListener(this);
            add(calculator);

            JLabel exitLabel = new JLabel("Exit");
            exitLabel.setBounds(210, 370, 100, 20);
            exitLabel.setFont(new Font("SansSerif", Font.BOLD, 16));
            add(exitLabel);

            JButton exit = new JButton("Log out");
            exit.setBounds(90, 400, 270, 30);
            exit.addActionListener(this);
            add(exit);

            ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/project1.jpg"));
            JLabel image = new JLabel(i1);
            image.setBounds(420, 120, 300, 300); 
            add(image);
            
        } else {
            
            JLabel infoLabel = new JLabel("Information");
            infoLabel.setBounds(180, 70, 100, 20);
            infoLabel.setFont(new Font("SansSerif", Font.BOLD, 16));
            add(infoLabel);

            JButton updateInfo = new JButton("Update Information");
            updateInfo.setBounds(90, 100, 270, 30);
            updateInfo.addActionListener(this);
            add(updateInfo);

            JButton viewInfo = new JButton("View Information");
            viewInfo.setBounds(90, 140, 270, 30);
            viewInfo.addActionListener(this);
            add(viewInfo);

            JLabel userLabel = new JLabel("User");
            userLabel.setBounds(205, 170, 270, 30);
            userLabel.setFont(new Font("SansSerif", Font.BOLD, 16));
            add(userLabel);

            JButton payBill = new JButton("Pay Bill");
            payBill.setBounds(90, 200, 270, 30);
            payBill.addActionListener(this);
            add(payBill);

            JButton billDetails = new JButton("Bill Details");
            billDetails.setBounds(90, 240, 270, 30);
            billDetails.addActionListener(this);
            add(billDetails);


            JButton generatebill = new JButton("Generate Bill");
            generatebill.setBounds(90, 280, 270, 30);
            generatebill.addActionListener(this);
            add(generatebill);
            
            JLabel utilityLabel = new JLabel("Utility");
            utilityLabel.setBounds(202, 310, 270, 30);
            utilityLabel.setFont(new Font("SansSerif", Font.BOLD, 16));
            add(utilityLabel);

            JButton notepad = new JButton("Notepad");
            notepad.setBounds(90,340, 270, 30);
            notepad.addActionListener(this);
            add(notepad);

            JButton calculator = new JButton("Calculator");
            calculator.setBounds(90, 380, 270, 30);
            calculator.addActionListener(this);
            add(calculator);


            JButton exit = new JButton("Log out");
            exit.setBounds(90, 420, 270, 30);
            exit.addActionListener(this);
            add(exit);
            
            
            ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/Project2.jpg"));
            JLabel image = new JLabel(i1);
            image.setBounds(380, 120, 300, 300);  
            add(image);
        }

        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        String action = ae.getActionCommand();

        switch (action) {
            case "Add New Customer":
                new NewCustomer();
                break;
            case "Customer Details":
                new CustomerDetails();
                break;
            case "Deposit Details":
                new DepositDetails();
                break;
            case "Calculate Bill":
                new CalculateBill();
                break;
            case "Update Information":
                new UpdateInformation(meter);
                break;
            case "View Information":
                new ViewInformation(meter);
                break;
            case "Pay Bill":
                new PayBill(meter);
                break;
            case "Bill Details":
                new BillDetails(meter);
                break;
            case "Generate Bill":
                new GenerateBill(meter);
                break;
            case "Notepad":
                try {
                    Runtime.getRuntime().exec("notepad.exe");
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            case "Calculator":
                try {
                    Runtime.getRuntime().exec("calc.exe");
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            case "Log out":
                setVisible(false);
                new Login();
                break;
            default:
                System.out.println("No action defined for: " + action);
        }
    }

    public static void main(String[] args) {
        new Project("Admin", "");
    }
}
